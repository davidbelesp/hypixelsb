
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.hypixelsb.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.hypixelsb.item.PerfectTopazItem;
import net.mcreator.hypixelsb.item.PerfectSapphireItem;
import net.mcreator.hypixelsb.item.PerfectRubyItem;
import net.mcreator.hypixelsb.item.PerfectAmethystItem;
import net.mcreator.hypixelsb.item.NecronsHandleItem;
import net.mcreator.hypixelsb.item.HyperionItem;
import net.mcreator.hypixelsb.item.GyrokineticWandItem;
import net.mcreator.hypixelsb.item.FlawedTopazItem;
import net.mcreator.hypixelsb.item.FlawedSapphireItem;
import net.mcreator.hypixelsb.item.FlawedRubyItem;
import net.mcreator.hypixelsb.item.FlawedAmethystItem;
import net.mcreator.hypixelsb.item.FineTopazItem;
import net.mcreator.hypixelsb.item.FineSapphireItem;
import net.mcreator.hypixelsb.item.FineRubyItem;
import net.mcreator.hypixelsb.item.FineAmethystItem;
import net.mcreator.hypixelsb.item.AspectOfTheVoidItem;
import net.mcreator.hypixelsb.HypixelsbMod;

public class HypixelsbModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, HypixelsbMod.MODID);
	public static final RegistryObject<Item> NECRONS_HANDLE = REGISTRY.register("necrons_handle", () -> new NecronsHandleItem());
	public static final RegistryObject<Item> HYPERION = REGISTRY.register("hyperion", () -> new HyperionItem());
	public static final RegistryObject<Item> ASPECT_OF_THE_VOID = REGISTRY.register("aspect_of_the_void", () -> new AspectOfTheVoidItem());
	public static final RegistryObject<Item> GYROKINETIC_WAND = REGISTRY.register("gyrokinetic_wand", () -> new GyrokineticWandItem());
	public static final RegistryObject<Item> FLAWED_RUBY = REGISTRY.register("flawed_ruby", () -> new FlawedRubyItem());
	public static final RegistryObject<Item> FLAWED_SAPPHIRE = REGISTRY.register("flawed_sapphire", () -> new FlawedSapphireItem());
	public static final RegistryObject<Item> FLAWED_TOPAZ = REGISTRY.register("flawed_topaz", () -> new FlawedTopazItem());
	public static final RegistryObject<Item> FLAWED_AMETHYST = REGISTRY.register("flawed_amethyst", () -> new FlawedAmethystItem());
	public static final RegistryObject<Item> FINE_RUBY = REGISTRY.register("fine_ruby", () -> new FineRubyItem());
	public static final RegistryObject<Item> FINE_SAPPHIRE = REGISTRY.register("fine_sapphire", () -> new FineSapphireItem());
	public static final RegistryObject<Item> FINE_TOPAZ = REGISTRY.register("fine_topaz", () -> new FineTopazItem());
	public static final RegistryObject<Item> FINE_AMETHYST = REGISTRY.register("fine_amethyst", () -> new FineAmethystItem());
	public static final RegistryObject<Item> PERFECT_RUBY = REGISTRY.register("perfect_ruby", () -> new PerfectRubyItem());
	public static final RegistryObject<Item> PERFECT_SAPPHIRE = REGISTRY.register("perfect_sapphire", () -> new PerfectSapphireItem());
	public static final RegistryObject<Item> PERFECT_TOPAZ = REGISTRY.register("perfect_topaz", () -> new PerfectTopazItem());
	public static final RegistryObject<Item> PERFECT_AMETHYST = REGISTRY.register("perfect_amethyst", () -> new PerfectAmethystItem());
}
