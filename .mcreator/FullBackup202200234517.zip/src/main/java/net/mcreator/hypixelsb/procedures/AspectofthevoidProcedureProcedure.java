package net.mcreator.hypixelsb.procedures;

public class AspectofthevoidProcedureProcedure {
	public static void execute() {
	}
}
